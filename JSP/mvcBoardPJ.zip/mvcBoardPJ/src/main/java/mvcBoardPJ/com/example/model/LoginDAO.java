package mvcBoardPJ.com.example.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import mvcBoardPJ.com.example.domain.Member;

public class LoginDAO {
	private DataSource ds;
	
	LoginDAO() {
		try {
			Context initContext = new InitialContext();
			Context envContext = (Context)initContext.lookup("java:/comp/env");
			ds = (DataSource)envContext.lookup("jdbc/gotit");
		} catch (NamingException ne) {
			System.out.println("JNDI 로딩 오류 : " + ne);
		}
	}
	
	Member getLoginInfo(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "select * from USERS where USER_ID=?";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				//String id = rs.getString(1);
				String pwd = rs.getString(2);
				
				return new Member(id, pwd);
			} else {
				return null;
			}
		} catch (SQLException se) {
			System.out.println("로그인 정보 불러오는 SQL 오류 : " + se);
			return null;
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (conn != null) conn.close();
			} catch (SQLException se) {
				System.out.println("close 오류가 발생한다고?? : " + se);
			}
		}
	}
}
