package mvcBoardPJ.com.example.model;

import mvcBoardPJ.com.example.domain.Member;

public class LoginService {
	private LoginDAO loginDao;
	
	private static final LoginService instance = new LoginService();
	// 싱글톤 (객체 하나 생성 후 우려먹기)
	
	private LoginService() {
		loginDao = new LoginDAO();
	}
	
	public static LoginService getInstance() {
		return instance;
	}
	
	public Member getLoginInfos(String id) {
		Member m = loginDao.getLoginInfo(id);
		m.setPwd("");
		
		return m;
	}
	
	public String check(String id, String password_hash) {
		Member m = loginDao.getLoginInfo(id);
		
		if (m == null) {
			return "null";
		} else {
			String dbPwd = m.getPwd();
			if (dbPwd != null) dbPwd.trim();
			
			if (!dbPwd.equals(password_hash)) {
				return "pwdError";
			} else {
				return "success";
			}
		}
	}
}
